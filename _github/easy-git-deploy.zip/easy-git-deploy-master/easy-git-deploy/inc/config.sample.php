<?php
/* rename this file to config.php! */

$config = array(

    // The directory where your website and git repository are located, can be a relative or absolute path
    'directory' => '../my_repo',

    // Used for first clone
    'url' => 'https://USER:PASS@bitbucket.org/account/repo.git'

    // Further options: 'log', 'date_format', 'branch', 'remote'
);